

<?php $__env->startSection('content'); ?>
    <!-- ========== tab components start ========== -->
    <section class="tab-components">
        <div class="container-fluid">
            <!-- ========== title-wrapper start ========== -->
            <div class="title-wrapper pt-30">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <div class="title mb-30">
                            <h2>Form Elements</h2>
                        </div>
                    </div>
                    <!-- end col -->
                    <div class="col-md-6">
                        <div class="breadcrumb-wrapper mb-30">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">
                                        <a href="#0">Dashboard</a>
                                    </li>
                                    <li class="breadcrumb-item"><a href="#0">Forms</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">
                                        Form Elements
                                    </li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <!-- end col -->
                </div>
                <!-- end row -->
            </div>
            <!-- ========== title-wrapper end ========== -->

            <!-- ========== form-elements-wrapper start ========== -->
            <form enctype="multipart/form-data" name="demoform" method="post" action="/upload" class="form-elements-wrapper">
               <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-lg-6">
                        <!-- input style start -->
                        <div class="card-style mb-30">

                            <div class="input-style-1">
                                <label>Main Title</label>
                                <input type="text" name="alldata['main_title']" placeholder="Main Title" />
                            </div>
                            <!------------------------------------------>


                            <div class="input-style-1">
                                <label>Choose Main Image</label>
                                <input type="file"  name="alldata['main_image']" />
                            </div>

                            <!-------------------------------------------->
                            <div class="input-style-1">
                                <label>the title under image</label>
                                <input type="text" name="alldata['image_title']" placeholder="write title" />
                            </div>
                        </div>
                        <!-- end card -->
                        <!-------------this card---------------->
                        <!-- ======= input style end ======= -->

                        <!-- ======= select style start ======= -->
                        <div class="card-style mb-30">
                            <div class="select-style-1">
                                <div class="select-position">
                                    <select name="alldata['journalist_name']">
                                        <option >Select journalist name</option>
                                        <option value="1">journalist_name one</option>
                                        <option value="2">journalist_name two</option>
                                        <option value="3">journalist_name three</option>
                                        <option selected value="4">journalist_name main</option>

                                    </select>
                                </div>
                            </div>
                            <!-- end select -->
                        </div>
                        <!-- end card -->
                        <!-- ======= select style end ======= -->


                    </div>


                    <!-- end col -->
                    <div class="col-lg-6">
                        <!------------------------------------------>
                        <!-- ======= textarea style start ======= -->
                        <div class="card-style mb-30">
                        <div class="input-style-1">
                            <label>Message</label>
                            <textarea placeholder="Message" name="tags" rows="5"></textarea>
                        </div>
                        </div>
                        <!-- end textarea -->

                        <!-- ======= textarea style start ======= -->



                        <!------------------------------------------>
                        <!-- ======= select style start ======= -->
                        <div class="card-style mb-30">
                            <div class="select-style-1">
                                <div class="select-position">
                                    <select name="alldata['image_title']">
                                        <option value="">Select category</option>
                                        <option value="">Category one</option>
                                        <option value="">Category two</option>
                                        <option value="">Category three</option>
                                    </select>
                                </div>
                            </div>
                            <!-- end select -->
                        </div>
                        <!-- end card -->
                        <!-- ======= select style end ======= -->

                    </div>
                    <!-- end col -->
                </div>
                <!-- end row -->

                <div class="row">

                        <!------------------------------------>


                        <!-- ======= textarea text editor style start ======= -->
                    <div class="card-style mb-30">

                        <textarea class="form-control" name="alldata['editor']" id="task_textarea" rows="5"></textarea>
                        <!-- end textarea -->
                    </div>

                        <!-- ======= textarea text editor style start ======= -->
                </div><!-- end row-->
                <button type="submit" id="submit-all"> upload </button>
            </form>
            <!-- ========== form-elements-wrapper end ========== -->
        </div>
        <!-- end container -->

    </section>
    <!-- ========== tab components end ========== -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script>
        //####################ck editor#####################
        let lang = '<?php echo app()->getLocale(); ?>';
        ClassicEditor
    .create( document.querySelector( '#task_textarea' ), {
    language: lang
    } )
    .then( editor => {
    window.editor = editor;
    } )
    .catch( err => {
    console.error( err.stack );
    } );
        //####################end ck editor#####################
    </script>


    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\journal-main\journal-main\resources\views/admin/news.blade.php ENDPATH**/ ?>